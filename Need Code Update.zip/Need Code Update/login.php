<html>
<form name="login"action="localhost/app.php">
Username<input type="text" name="userid"/>
Password<input type="password" name="pswrd"/><br><br>
<input type="button" onclick="check(this.form)" value="Login"/>
<input type="reset" value="Cancel"/>
</form>
<script language="javascript">
function check(form) { /*function to check userid & password*/
/*the following code checkes whether the entered userid and password are matching*/
if(form.userid.value == form.pswrd.value) {
window.open('app.php')/*opens the target page while Id & password matches*/
}
else {
alert("Error Password or Username")/*displays error message*/
}
}
</script>
  
</html>